<template>
  <div class="container">
    <div id="top">     
      <mt-header fixed title="" class="top"></mt-header>
      <mt-search fixed class="is-fixed" cancel-text=""></mt-search>
      <img src="../picture/logo4.png" alt="logo" class="logo">     
    </div>
    <div class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
      <div class="mui-scroll">
          <router-link class="mui-control-item mui-active" to="/">
              推荐
          </router-link>
          <router-link class="mui-control-item" to="/hot">
              热点
          </router-link>
          <a class="mui-control-item">
              北京
          </a>
          <a class="mui-control-item">
              社会
          </a>
          <a class="mui-control-item">
              娱乐
          </a>
          <a class="mui-control-item">
              科技
          </a>
          <a class="mui-control-item">
              科技
          </a>
          <a class="mui-control-item">
              科技
          </a>
          <a class="mui-control-item">
              科技
          </a>
          <a class="mui-control-item">
              科技
          </a>
          <a class="mui-control-item">
              科技
          </a>
        </div>
    </div>
    <div class="wrap">
      <mt-loadmore :top-method="loadTop" 
      :bottom-method="loadBottom" 
      ref="loadmore"
      :autoFill="false">
           <!-- :bottom-all-loaded="allLoaded" -->
        <ul class="mint_wrap" v-if="$store.state.loading">
          
          <li v-for="(items, index) in list" :key="index">
            <router-link class="inner">
            <div class="wrap_l">
              <p>{{ items.id }}</p>
              <div class="boot">
                <span>{{  }}</span><em></em>
              </div>
            </div>
              <div class="wrap_r">
                <img src="" alt="loading…">
              </div>
            </router-link>
          </li>
        </ul>
      </mt-loadmore>   
    </div>
  </div>
</template>

<script>
import mui from '../lib/mui/mui.js'
import { randomId } from '../request/randomId.js'
import { mapState, mapActions, mapGetters } from 'vuex'

export default {
  data() {
    return {

    }
  },
  created(){
    console.log(this.$store.state.list)
    this.getNews() 
    // console.log(this.$store.state.list)
  },
  computed:{
    ...mapState(['list', 'cont', 'loading']),
    ...mapGetters(['addNews'])
  },
  methods: {
    getNews(){
      this.$store.dispatch('getList')
      // var url = 'http://www.toutiao.com/api/comment/list/?group_id=6364965628189327618&item_id=6364969235889783298&offset=0&count=10'
      // this.$axios.get(url).then( res=> {
      //   this.$store.state.list = res.data.data.comments
      //   console.log(this.$store.state.list) 
      // })
      // console.log(this.$store.state.list)
    },
    loadTop(){
      //加载更多数据
      this.$refs.loadmore.onTopLoaded(); 
    },

    loadBottom() {
      //加载更多数据
        var catid = randomId()
        this.$axios.get('http://api01.idataapi.cn:8000/news/toutiao?apikey=N1seT9CY1OtWboWiXs3b2BtgnQj4ZW3DXQDubud0w4IAAn9cnwEpNZX3shUvjEG7&catid='+ catid +'&pageToken=0')
        .then( res=> {
            this.list = this.list.concat( res.data.data )
        })
        .catch(err=>{
          console.log(err)
          // this.loadBottom()
        })
      this.allLoaded = false;
      this.$refs.loadmore.onBottomLoaded();
		}
 
  },
	beforeRouteLeave (to, from, next) {
			this.scrollTop = document.querySelector('.wrap').scrollTop
			next()
		},
	beforeRouteEnter (to, from, next) {
			next(vm => {
				document.querySelector('.wrap').scrollTop = vm.scrollTop
			})
	},


}
</script>


<style>

a{
  text-decoration: none;
}
.container{
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}
.wrap_top{
  width: 100%;
  height: 90px;
}
#top{
  width: 100%;
  height: 50px;
}
.top{
  width: 100%;
  height: 50px !important ;
}
.mint-header{
  background-color: #D43D3D;
}
.mint-searchbar{
  position: absolute;
  right: 5px;
  padding: 0;
  width: 160px;
  height: 30px;
  background-color: #D43D3D;
  margin-top: 10px; 
}
.mint-searchbar-core{
  border-radius: 20px;
}
.mint-searchbar-inner{
    padding-top: 0;
    padding-bottom: 0; 
    height: 100%;
    border-radius: 50px;
}
.logo{
    position: absolute;
    top: 0;
    z-index: 10;
    left: 25px;
}

.mui-scroll-wrapper{
  width: 100%;
  height: 40px;
  overflow: hidden;
  background: #F4F5F6;
}
.mui-scroll{
  width: 550px;
  height: 40px;
}
.mui-control-item{
  display: inline-block;
  width: 50px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  font-weight: normal;
  text-decoration: none;
  color: #0a0a0a;
}
.mui-active{
  color: #F77A7A;
}
.wrap{
  height: 100%;
  /* overflow: auto; */
  overflow-y: scroll; 
   -webkit-overflow-scrolling: touch;
  /* overflow: hidden; */
}
.mint-loadmore{
  margin-bottom: 40px;
}
.mint_wrap{
  margin: 0;
  padding: 0;
  margin-bottom: 40px;
}
.mint_wrap li{
  list-style: none;
}
.inner{
  padding: 12px 0  16px 0;
  display: flex;
  margin: 0 auto;
  justify-content: space-around;
  border-bottom: 1px solid #cccccc;
}
.wrap_l{
  width: 200px;
}
.wrap_l p{
    margin: 0 0 5px 0;
    white-space: normal;
    font-size: 16px;
    line-height: 21px;
     color: #222; 
    font-weight: 400;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    text-overflow: ellipsis;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.boot{
  color: #cccccc;
  font-size: 8px;
}
.boot span{
  margin-right: 10px;
}
.boot em{
  font-style: normal;
}
.wrap_r{
  width: 115px;
  height: 74px;
}
.wrap_r img{
  display: inline-block;
  width: 100%;
  height: 100%;
}
</style>

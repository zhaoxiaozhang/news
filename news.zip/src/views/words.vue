<template>
<div>
    <mt-header fixed title="重磅·头条号" class="fex_header">
      <router-link to='' slot="left">
        <mt-button icon="back" @click="goback()"></mt-button>
      </router-link>
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>
    <!-- <div class="content" v-for="(items, index) in list" :key="index"> -->
      <div class="top">
        <!-- <h2>{{ items.title }}</h2> -->
        <!-- <span>{{ items.posterScreenName }}</span><em>{{ items.publishDateStr }}</em> -->
      </div>
      <div class="product">
        <!-- <img :src="items.imageUrls[0]" alt=""> -->
        <!-- <div class="pro_p" v-html="items.content"></div> -->
        <div class="tuijian"><em>——</em><span>相关推荐</span><em>——</em></div>
      </div>

    <!--  <div class="bt" >
        <li v-for="(list, index) in next" :key="index">
          <router-link class="inner" :to="{name: 'Words', query: {id: items.id}}">
            <div class="wrap_l">
              <p>{{ list.title }}</p>
              <div class="boot">
                <span>{{ list.posterScreenName }}</span>
              </div>
            </div>
            <div class="wrap_r">
              <img :src="list.coverUrl" alt="loading…">
            </div>
          </router-link>
        </li>
      </div> -->

  <!-- </div> -->

    

</div>
 
</template>


<script>
import { randomId } from '../request/randomId.js'
import ScrollPosition from '../lib/scroll-position';
export default {
  props: ['contents'],
  data(){
    return{
      list:[],
      next:[]
    }
  },
  created(){
  //  this.getId()
  },
  mounted(){

  },
  methods:{
      
    getId(){ 
      var url = window.location.href
      var ids = url.split('=')
      var id = ids[1]    
      this.$axios.get('http://api.jisuapi.com/news/get?channel=%E5%A4%B4%E6%9D%A1&start=0&num=2&appkey=272f8fcb40a13a6e')
      .then( res=> {
        this.list = res.data.result.list
      })
      // this.getNext()
    },
    getNext(){
      var catid = randomId()
      this.$axios.get('http://api01.idataapi.cn:8000/news/toutiao?apikey=N1seT9CY1OtWboWiXs3b2BtgnQj4ZW3DXQDubud0w4IAAn9cnwEpNZX3shUvjEG7&catid='+ catid)
      .then( res=> {
        this.next = res.data.data
      })
      .catch(err=>{
        console.log(err)
        if(err){
          // this.getNext()
        }
      })
    },
    goback(){
      window.history.back()
    }


  }
}
</script>


<style>
.content{
  position: fixed;
  top: 50px;
  left: 0;
  right: 0;
  width: 100%;
  height: 100%;
  font-size: 20px;
  overflow: scroll;
}
.fex_header{
  width: 100%;
  height: 50px;
  background: white;
  color: black;
  font-weight: bold;
}
.mint-header-title{
  font-size: 18px;
  font-weight: 600;
  font-family: '宋体';
  color: #222
}
.mint-header{
  padding: 0 20px;
}
.mintui{
  font-size: 20px;
}

.top{
  width: 100%;
  height: 90px;
  box-sizing: border-box;
  padding: 0 15px;
  margin: 0 auto;
}
.top h2{
    font-size: 20px;
    margin: 8px 0;
}
.top span{
  font-size: 14px;
  margin-right: 8px;
}
.top em{
  font-size: 12px;
  font-style: normal;
}
.product{
  margin-top: 20px; 
  background: #F8F8F8;

}
.product article{
  padding: 0 15px;
  margin: 0 auto;
  text-align: center;
  border-bottom: 2px solid #cccccc;
  font-size: 17px;
  line-height: 1.5;
  color: #505050
 }
 .product article h1{
   border: 0;
   font-size: 20px;
 }
.product article strong{
   font-weight: normal;
 }
 .product img{
   box-sizing: border-box;
   padding: 0 15px;
   width: 100%;
   height: auto;
 }
 hedaer{
   font-size: 17px;
   padding: 0 20px;
   font-weight: normal;
   line-height: 1.5;
   color: #505050
 }

 .inner{
  padding: 12px 0  16px 0;
  display: flex;
  margin: 0 auto;
  justify-content: space-around;
  border-bottom: 1px solid #cccccc;
}
.wrap_l{
  width: 200px;
}
.wrap_l p{
    margin: 0 0 5px 0;
    white-space: normal;
    font-size: 16px;
    line-height: 21px;
     color: #222; 
    font-weight: 400;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    text-overflow: ellipsis;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.boot{
  color: #cccccc;
  font-size: 8px;
}
.boot span{
  margin-right: 10px;
}
.boot em{
  font-style: normal;
}
.wrap_r{
  width: 115px;
  height: 74px;
}
.wrap_r img{
  display: inline-block;
  width: 100%;
  height: 100%;
}
.tuijian{
  text-align: center;
  margin: 10px 0;
  background: white;
}
.tuijian span{
  margin: 0 5px;
  font-weight: bold;
  font-size: 15px;
}
.tuijian em{
  color: #cccccc;
}
.bt{
  margin-bottom: 50px;
}
.bt li{
  list-style: none;
}
</style>


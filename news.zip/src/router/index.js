import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/views/home.vue'
import Words from '@/views/words.vue'

Vue.use(Router)


export default new Router({
  meta: 'history',
  routes: [
    {
      path: '/',
      name: 'Home',
      // component: Home,
      // component:resolve => require(['@/views/home.vue'],resolve)
      meta:{
        keepAlive: true
      },
      component:resolve => require(['@/views/home.vue'],resolve),
    },
    {
      path: '/words/:id',
      name: 'Words',
      component: Words,
      meta:{
        keepAlive: false
      }
    }
  ]

})

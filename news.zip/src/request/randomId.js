  
function randomId(){
    var  list =  ['news_society', 'news_entertainment', 'news_car', 'news_sports', 'news_finance',
    'news_military', 'news_house', 'news_fashion', 'news_baby',
    'news_history', 'funny', 'digital', 'news_food', 'news_regimen', 'cellphone', 'news_house',
    'news_comic', 'news_story', 'news_astrology']
    var len = Math.floor(Math.random()*list.length)
    var catid = list[len]
    return catid
}
export {
  randomId
}
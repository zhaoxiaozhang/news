import Vue from 'vue'
import Vuex from 'vuex'
import Axios from 'axios';
Vue.use(Vuex)
// 相当于data对象的状态对象
const state = {
	list: [],
	loading: false
}
// 包含了n个直接更新状态的方法的对象
const mutations = {
	success ({commit}, {news}){
		state.list = news
	}
}
// 包含了n个间接更新状态的方法的对象
const actions = {
	getList ({commit}, state){
		const url = 'http://www.toutiao.com/api/comment/list/?group_id=6364965628189327618&item_id=6364969235889783298&offset=0&count=10'
		Axios.get(url).then( res=> {
			var news = res.data.data.comments
			commit('success', {news})
		})
	}
}
// 包含多个getter计算属性的对象
const getters = {

}

export default new Vuex.Store({
	state,
	mutations,
	actions,
	getters
})





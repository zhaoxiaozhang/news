<template>
	<div>
		<h1 class="dd">{{msg}}</h1>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				msg: '12345685'
			};
		}
	}
</script>

<style>
/* .dd{
	font-size: 18px;
	color: red;
} */
</style>
